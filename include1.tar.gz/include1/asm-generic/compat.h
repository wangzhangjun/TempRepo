/* SPDX-License-Identifier: GPL-2.0 */

/* This is an empty stub for 32-bit-only architectures */
